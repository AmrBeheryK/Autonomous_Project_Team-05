import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
import sys, select, termios, tty
import threading
import math

class TeleopNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_2_Teleop_Team_5')
        self.vel_pub = self.create_publisher(Float64, '/velocity', 10)
        self.steer_pub = self.create_publisher(Float64, '/steering_angle', 10)
        self.joint_sub = self.create_subscription(JointState, '/joint_states', self.joint_callback, 10)
        
        self.current_vel = 0.0
        self.current_steer = 0.0
        self.settings = termios.tcgetattr(sys.stdin)
        
        self.actual_steer = 0.0
        self.actual_vel = 0.0
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.yaw = 0.0
        
        self.last_time = self.get_clock().now()
        self.data_received = False

    def joint_callback(self, msg):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9
        self.last_time = current_time

        try:
            if 'front_left_steering_joint' in msg.name:
                idx_steer = msg.name.index('front_left_steering_joint')
                self.actual_steer = msg.position[idx_steer]
            if 'rear_left_wheel_joint' in msg.name:
                idx_vel = msg.name.index('rear_left_wheel_joint')
                self.actual_vel = msg.velocity[idx_vel]
                
            R = 0.05 
            L = 0.33 
            linear_v = self.actual_vel * R
            
            if dt < 1.0:
                self.yaw += (linear_v / L) * math.tan(self.actual_steer) * dt
                self.pos_x += linear_v * math.cos(self.yaw) * dt
                self.pos_y += linear_v * math.sin(self.yaw) * dt
                
            self.data_received = True
        except ValueError:
            pass

    def run_teleop(self):
        print('\r\n--- Teleop Started ---')
        print('1. CLICK ON THIS TERMINAL WINDOW TO GIVE IT FOCUS')
        print('2. Use UP/DOWN arrows to accelerate/brake')
        print('3. Use LEFT/RIGHT arrows to steer')
        print('4. Press Ctrl+C to exit\r\n')
        
        try:
            while rclpy.ok():
                tty.setraw(sys.stdin.fileno())
                rlist, _, _ = select.select([sys.stdin], [], [], 0.1) 
                if rlist:
                    key = sys.stdin.read(1)
                    if key == '\x1b':
                        key += sys.stdin.read(2)
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
                    
                    if key == '\x1b[A':   
                        self.current_vel += 0.5
                    elif key == '\x1b[B': 
                        self.current_vel -= 0.5
                    elif key == '\x1b[C': 
                        self.current_steer -= 0.1
                    elif key == '\x1b[D': 
                        self.current_steer += 0.1
                    elif key == '\x03':   
                        break
                else:
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
                
                # Cruise Control Publishing
                vel_msg = Float64()
                steer_msg = Float64()
                vel_msg.data = self.current_vel
                steer_msg.data = self.current_steer
                self.vel_pub.publish(vel_msg)
                self.steer_pub.publish(steer_msg)
                
                if self.data_received:
                    linear_v = self.actual_vel * 0.05
                    sys.stdout.write(f"\rState -> Steer: {math.degrees(self.actual_steer):.1f}°, Vel: {linear_v:.1f} m/s, Pos: ({self.pos_x:.1f}, {self.pos_y:.1f}), Orient: {math.degrees(self.yaw):.0f}°      ")
                    sys.stdout.flush()
        except Exception as e:
            print(f"\nError: {e}")
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,))
    spin_thread.start()
    node.run_teleop()
    node.destroy_node()
    rclpy.shutdown()
    spin_thread.join()

if __name__ == '__main__':
    main()
