import rclpy
from rclpy.node import Node

class ValidationNode(Node):
    def __init__(self):
        
        super().__init__('validation_printing_node_team_5')
         
        self.get_logger().info('Hello world line')

def main(args=None):
    rclpy.init(args=args)
    node = ValidationNode()
    rclpy.spin_once(node, timeout_sec=1.0)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
