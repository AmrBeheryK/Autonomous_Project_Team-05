#include <Servo.h>

Servo steeringServo;

// Pins
const int pwmPin = 5;
const int dirPin1 = 3;
const int dirPin2 = 4;
const int servoPin = 9;

// Variables
int pwmValue = 0;
int steeringAngle = 90;
int direction = 1; // 1 forward, -1 reverse

unsigned long lastCommandTime = 0;
const unsigned long timeout = 1000;

String inputBuffer = "";

void setup() {
  Serial.begin(115200);

  pinMode(pwmPin, OUTPUT);
  pinMode(dirPin1, OUTPUT);
  pinMode(dirPin2, OUTPUT);

  steeringServo.attach(servoPin);
  steeringServo.write(steeringAngle);
}

void loop() {
  readSerial();

  // Apply direction
  if (direction == 1) {
    digitalWrite(dirPin1, HIGH);
    digitalWrite(dirPin2, LOW);
  } else {
    digitalWrite(dirPin1, LOW);
    digitalWrite(dirPin2, HIGH);
  }

  // Apply PWM
  analogWrite(pwmPin, pwmValue);

  // Apply steering
  steeringServo.write(steeringAngle);

  // Safety timeout
  if (millis() - lastCommandTime > timeout) {
    analogWrite(pwmPin, 0);
  }
}

void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();

    if (c == '\n') {
      parseCommand(inputBuffer);
      inputBuffer = "";
    } else {
      inputBuffer += c;
    }
  }
}

void parseCommand(String cmd) {
  // Expected: <PWM,ANGLE,DIR>
  if (cmd.startsWith("<") && cmd.endsWith(">")) {
    cmd.remove(0, 1);
    cmd.remove(cmd.length() - 1);

    int firstComma = cmd.indexOf(',');
    int secondComma = cmd.indexOf(',', firstComma + 1);

    if (firstComma > 0 && secondComma > firstComma) {
      String pwmStr = cmd.substring(0, firstComma);
      String angleStr = cmd.substring(firstComma + 1, secondComma);
      String dirStr = cmd.substring(secondComma + 1);

      pwmValue = constrain(pwmStr.toInt(), 0, 255);
      steeringAngle = constrain(angleStr.toInt(), 0, 180);
      direction = dirStr.toInt();

      lastCommandTime = millis();
    }
  }
}