import rclpy
from rclpy.node import Node
import serial
import sys
import termios
import tty

class AckermannKeyboard(Node):

    def __init__(self):
        super().__init__('ackermann_keyboard')

        # Serial connection
        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

        # Control state
        self.active = False

        self.pwm = 0
        self.angle = 90

        # Parameters
        self.pwm_step = 10
        self.angle_step = 5

        self.stop_angle = 90

        self.get_logger().info("Node started. Press 's' to start, 'c' to stop.")

        self.run()

    def get_key(self):
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        try:
            tty.setraw(fd)
            ch1 = sys.stdin.read(1)

            if ch1 == '\x1b':  # Arrow keys
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                return ch1 + ch2 + ch3
            else:
                return ch1

        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def send_command(self):
        if self.pwm < 0:
            direction = -1
            pwm_to_send = abs(self.pwm)
        else:
            direction = 1
            pwm_to_send = self.pwm

        msg = f"<{pwm_to_send},{self.angle},{direction}>\n"
        self.ser.write(msg.encode())

    def run(self):
        while rclpy.ok():
            key = self.get_key()

            # Start command mode
            if key == 's':
                self.active = True

                self.pwm = int(input("Enter initial PWM (0-255): "))
                self.angle = int(input("Enter initial angle (0-180): "))

                self.get_logger().info("Control activated")

            # Cancel / stop
            elif key == 'c':
                self.active = False
                self.pwm = 0
                self.angle = self.stop_angle
                self.send_command()

                self.get_logger().info("Control stopped")

            if not self.active:
                continue

            # Arrow keys
            if key == '\x1b[A':  # Up
                self.pwm += self.pwm_step

            elif key == '\x1b[B':  # Down
                self.pwm -= self.pwm_step

            elif key == '\x1b[C':  # Right
                self.angle += self.angle_step

            elif key == '\x1b[D':  # Left
                self.angle -= self.angle_step

            # Clamp values
            self.pwm = max(-255, min(255, self.pwm))
            self.angle = max(0, min(180, self.angle))

            self.send_command()

            self.get_logger().info(f"PWM: {self.pwm}, Angle: {self.angle}")


def main(args=None):
    rclpy.init(args=args)
    node = AckermannKeyboard()
    rclpy.shutdown()


if __name__ == '__main__':
    main()