import pandas as pd
import matplotlib.pyplot as plt

# List of your CSV files
files = ['velocity.csv', 'x.csv', 'y.csv', 'yaw.csv']

for file in files:
    # Read the CSV file
    df = pd.read_csv(file)
    
    # Create a new figure for each file
    plt.figure(figsize=(10, 6))
    
    # Assuming the first column is 'time' (x-axis)
    time_col = df.columns[0]
    
    # Plot the remaining columns against time (y-axis)
    for col in df.columns[1:]:
        plt.plot(df[time_col], df[col], label=col)
        
    # Add title, labels, and legend
    plt.title(f'Track 1 - {file.split(".")[0].capitalize()}')
    plt.xlabel(time_col)
    plt.ylabel('Value')
    plt.legend()
    plt.grid(True)
    
    # Ensure layout fits well
    plt.tight_layout()
    
    # Save the plot as an image and also display it
    plt.savefig(f'{file.split(".")[0]}_plot.png')
    plt.show()