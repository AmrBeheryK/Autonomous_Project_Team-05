import math

def build_slot_car_track():
    print("🛠️ Building Low-Friction Intersecting Figure-8 Track...")

    D = 2.5
    R = 1.5
    theta = math.asin(R / D) 
    arc_angle = math.pi + 2 * theta
    arc_len = R * arc_angle
    total_len = 4.0 + 2 * arc_len
    thickness = 0.6
    num_points = 300

    path_x, path_y, path_yaw, path_ds = [], [], [], []

    for i in range(num_points):
        s = i * (total_len / num_points)

        if s < 2.0:
            x, y, yaw = s * math.cos(theta), s * math.sin(theta), theta
        elif s < 2.0 + arc_len:
            s_arc = s - 2.0
            gamma = (math.pi/2 + theta) - (s_arc / R)
            x, y = D + R * math.cos(gamma), R * math.sin(gamma)
            yaw = gamma - math.pi/2
        elif s < 2.0 + arc_len + 4.0:
            s_str = s - (2.0 + arc_len)
            x, y = 1.6 - s_str * math.cos(theta), -1.2 + s_str * math.sin(theta)
            yaw = math.pi - theta
        elif s < 2.0 + 2*arc_len + 4.0:
            s_arc2 = s - (2.0 + arc_len + 4.0)
            gamma = (math.pi/2 - theta) + (s_arc2 / R)
            x, y = -D + R * math.cos(gamma), R * math.sin(gamma)
            yaw = gamma + math.pi/2
        else:
            s_str2 = s - (2.0 + 2*arc_len + 4.0)
            x, y = -1.6 + s_str2 * math.cos(theta), -1.2 + s_str2 * math.sin(theta)
            yaw = theta

        path_x.append(x)
        path_y.append(y)
        path_yaw.append(yaw)

    for i in range(num_points):
        nxt_i = (i + 1) % num_points
        dx, dy = path_x[nxt_i] - path_x[i], path_y[nxt_i] - path_y[i]
        path_ds.append(math.sqrt(dx**2 + dy**2) + 0.15)

    csv_content = "Node_X,Node_Y\n"
    for i in range(num_points):
        csv_content += f"{path_x[i]:.4f},{path_y[i]:.4f}\n"
        
    with open('planned_path_figure8.csv', 'w') as f:
        f.write(csv_content)

    # ── THE FIX: Friction is dropped to 0.1 so the extreme steering won't jam the car ──
    world_xml = f"""<?xml version="1.0" ?>
<sdf version="1.8">
  <world name="Figure8_Track">
    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"></plugin>
    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"></plugin>
    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"></plugin>
    <plugin filename="gz-sim-contact-system" name="gz::sim::systems::Contact"></plugin>
    <gravity>0 0 -9.8</gravity>
    <scene><ambient>1.0 1.0 1.0 1.0</ambient><background>0.5 0.8 0.9 1.0</background></scene>
    <light type="directional" name="sun">
      <cast_shadows>true</cast_shadows><pose>0 0 10 0 0 0</pose>
      <diffuse>0.8 0.8 0.8 1</diffuse><specular>0.2 0.2 0.2 1</specular><direction>-0.5 0.1 -0.9</direction>
    </light>
    <model name="ground_plane">
      <static>true</static>
      <link name="link">
        <collision name="collision">
          <geometry><plane><normal>0 0 1</normal><size>1000 1000</size></plane></geometry>
          <surface><friction><ode><mu>0.1</mu><mu2>0.1</mu2></ode></friction></surface>
        </collision>
        <visual name="visual">
          <geometry><plane><normal>0 0 1</normal><size>1000 1000</size></plane></geometry>
          <material><ambient>0.8 0.8 0.8 1</ambient><diffuse>0.8 0.8 0.8 1</diffuse></material>
        </visual>
      </link>
    </model>
"""
    for i in range(num_points):
        world_xml += f"""
    <model name="track_segment_{i}">
      <static>true</static>
      <link name="link">
        <pose>{path_x[i]:.4f} {path_y[i]:.4f} 0.001 0 0 {path_yaw[i]:.4f}</pose>
        <visual name="visual">
          <geometry><box><size>{path_ds[i]:.4f} {thickness} 0.002</size></box></geometry>
          <material><ambient>0.2 0.2 0.2 1</ambient><diffuse>0.2 0.2 0.2 1</diffuse></material>
        </visual>
      </link>
    </model>"""

    world_xml += "\n  </world>\n</sdf>"
    with open('Figure8_Track.world', 'w') as f:
        f.write(world_xml)
    print("✅ Created: Low-Friction Intersecting Figure8_Track.world")

if __name__ == "__main__":
    build_slot_car_track()
