import rclpy
from rclpy.node import Node
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32MultiArray
import numpy as np
import math

# ─────────────────────────────────────────────
#  Utility
# ─────────────────────────────────────────────
def normalize_angle(angle):
    return (angle + math.pi) % (2 * math.pi) - math.pi


# ─────────────────────────────────────────────
#  Node
# ─────────────────────────────────────────────
class LocalizationNode(Node):
  

    def __init__(self):
        super().__init__('Autonomous_Systems_MS_5_Localization_Team_5')

        # ── Noise parameters – names match Autonomous_Systems_MS_5_Team_5.launch.py ──
        self.declare_parameter('noise_std_dev_yaw',   0.001)   # std-dev θ      [rad]
        self.declare_parameter('noise_std_dev_v',     0.002)   # std-dev v/pos  [m/s,m]
        self.declare_parameter('noise_std_dev_omega', 0.0005)   # std-dev omega  [rad/s]
        
        # ── NEW: Toggle for Comparison Mode ──
        self.declare_parameter('use_filter', True)

        # ── Subscriptions ────────────────────────────────────────────────────
        self.sub_gt = self.create_subscription(
            TFMessage, '/ground_truth', self._gt_callback, 10)
        self.sub_joints = self.create_subscription(
            JointState, '/joint_states', self._joint_callback, 10)

        # ── Publisher ────────────────────────────────────────────────────────
        # Float32MultiArray layout: [x, y, theta, v]
        self.pub_filtered = self.create_publisher(
            Float32MultiArray, '/filtered_state', 10)

        # ── Ground-truth cache ────────────────────────────────────────────────
        self.gt_x     = 0.0
        self.gt_y     = 0.0
        self.gt_theta = 0.0
        self.v_meas   = 0.0   # wheel-encoder speed
        self.gt_received = False

        # ── EKF state  x̂ = [x, y, θ]ᵀ ────────────────────────────────────────
        self.x_hat = np.zeros((3, 1))
        self.P     = np.eye(3) * 0.1

        # ── Timing ────────────────────────────────────────────────────────────
        self._last_time  = None   
        self._prev_theta = 0.0   

        # ── History for post-run plotting ─────────────────────────────────────
        self.history_gt      = []   
        self.history_noisy   = []   
        self.history_filtered = []  

        # Main loop at 10 Hz (matches controller rate)
        self.timer = self.create_timer(0.1, self._localization_loop)
        self.get_logger().info('MS-5 Localization Node (with Filter Toggle) started ✓')

    # ─────────────────────────────────────────
    #  Callbacks
    # ─────────────────────────────────────────
    def _gt_callback(self, msg: TFMessage):
        if not msg.transforms:
            return
        t = msg.transforms[0].transform
        self.gt_x = t.translation.x
        self.gt_y = t.translation.y
        q = t.rotation
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.gt_theta = math.atan2(siny_cosp, cosy_cosp)
        self.gt_received = True

    def _joint_callback(self, msg: JointState):
        try:
            if 'rear_left_wheel_joint' in msg.name:
                idx = msg.name.index('rear_left_wheel_joint')
                self.v_meas = msg.velocity[idx] * 0.05  # wheel radius = 0.05 m
        except ValueError:
            pass

    # ─────────────────────────────────────────
    #  Main localization loop
    # ─────────────────────────────────────────
    def _localization_loop(self):
        if not self.gt_received:
            return

        # ── Sim-clock time delta ───────────────────────────────────────────
        now = self.get_clock().now()
        if self._last_time is None:
            self._last_time  = now
            self._prev_theta = self.gt_theta
            self.x_hat = np.array([[self.gt_x],
                                   [self.gt_y],
                                   [self.gt_theta]])
            return

        dt = (now - self._last_time).nanoseconds * 1e-9
        dt = float(np.clip(dt, 0.01, 0.2))
        self._last_time = now

        # ── Read noise params ──────────────────────────────────────────────
        R_theta = float(self.get_parameter('noise_std_dev_yaw').value)
        R_xy    = float(self.get_parameter('noise_std_dev_v').value)
        R_x     = R_xy   
        R_y     = R_xy
        Q_v     = R_xy
        Q_omega = float(self.get_parameter('noise_std_dev_omega').value)
        
        use_filter = self.get_parameter('use_filter').value

        # ── Estimate angular velocity from GT (finite difference) ──────────
        d_theta = normalize_angle(self.gt_theta - self._prev_theta)
        omega_gt = d_theta / dt
        self._prev_theta = self.gt_theta

        # ── Step 1 – Inject Gaussian process noise onto inputs ─────────────
        v_noisy     = self.v_meas + np.random.normal(0.0, Q_v)
        omega_noisy = omega_gt   + np.random.normal(0.0, Q_omega)

        # ── Step 2 – Inject Gaussian measurement noise onto states ─────────
        x_noisy     = self.gt_x     + np.random.normal(0.0, R_x)
        y_noisy     = self.gt_y     + np.random.normal(0.0, R_y)
        theta_noisy = self.gt_theta + np.random.normal(0.0, R_theta)
        theta_noisy = normalize_angle(theta_noisy)

        # Store for plotting
        self.history_gt.append(     [self.gt_x,  self.gt_y,  self.gt_theta])
        self.history_noisy.append(  [x_noisy,    y_noisy,    theta_noisy])

        # ── Step 3 – EKF Prediction ────────────────────────────────────────
        theta_k = float(self.x_hat[2, 0])

        x_pred = self.x_hat + np.array([
            [v_noisy * dt * math.cos(theta_k)],
            [v_noisy * dt * math.sin(theta_k)],
            [omega_noisy * dt]
        ])
        x_pred[2, 0] = normalize_angle(float(x_pred[2, 0]))

        F = np.array([
            [1.0, 0.0, -v_noisy * dt * math.sin(theta_k)],
            [0.0, 1.0,  v_noisy * dt * math.cos(theta_k)],
            [0.0, 0.0,  1.0]
        ])

        Q_mat = np.diag([Q_v**2, Q_v**2, Q_omega**2])
        P_pred = F @ self.P @ F.T + Q_mat

        # ── Step 4 – EKF Update ────────────────────────────────────────────
        H = np.eye(3)                                        
        R_mat = np.diag([R_x**2, R_y**2, R_theta**2])       

        z = np.array([[x_noisy], [y_noisy], [theta_noisy]])

        innovation = z - H @ x_pred
        innovation[2, 0] = normalize_angle(float(innovation[2, 0]))

        S = H @ P_pred @ H.T + R_mat
        K = P_pred @ H.T @ np.linalg.inv(S)                 

        self.x_hat = x_pred + K @ innovation
        self.x_hat[2, 0] = normalize_angle(float(self.x_hat[2, 0]))
        self.P = (np.eye(3) - K @ H) @ P_pred

        # Store for plotting
        self.history_filtered.append([
            float(self.x_hat[0, 0]),
            float(self.x_hat[1, 0]),
            float(self.x_hat[2, 0])
        ])

        # ── Step 5 – Publish state (Filtered OR Raw Noisy) ─────────────────
        out = Float32MultiArray()
        
        if use_filter:
            # Send the clean, filtered data to the controllers
            out.data = [
                float(self.x_hat[0, 0]),   
                float(self.x_hat[1, 0]),   
                float(self.x_hat[2, 0]),   
                float(self.v_meas)         
            ]
            state_type = "Filt"
            state_str = f"({self.x_hat[0,0]:.2f},{self.x_hat[1,0]:.2f},{math.degrees(self.x_hat[2,0]):.1f}°)"
        else:
            # Send the raw, noisy data to the controllers
            out.data = [
                float(x_noisy),
                float(y_noisy),
                float(theta_noisy),
                float(v_noisy)
            ]
            state_type = "Raw "
            state_str = f"({x_noisy:.2f},{y_noisy:.2f},{math.degrees(theta_noisy):.1f}°)"

        self.pub_filtered.publish(out)

        self.get_logger().info(
            f'GT=({self.gt_x:.2f},{self.gt_y:.2f},{math.degrees(self.gt_theta):.1f}°) | '
            f'{state_type}={state_str}',
            throttle_duration_sec=0.5
        )

# ─────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
