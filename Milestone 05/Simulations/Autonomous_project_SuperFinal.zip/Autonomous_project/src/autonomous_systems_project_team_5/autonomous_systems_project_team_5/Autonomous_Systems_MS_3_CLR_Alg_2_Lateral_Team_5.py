import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from std_msgs.msg import Float32MultiArray   # ← MS-5: use filtered state
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Point
import math

class HybridLateralControllerNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_5')
        
        # --- Mode toggle ---
        self.declare_parameter('mode', 'lane')
        self.declare_parameter('lane_yaw', 0.0)

        # --- Waypoint from Planner ---
        self.sub_wp = self.create_subscription(
            Point, '/current_waypoint', self.wp_callback, 10)
        self.target_wp = Point()

        # ── MS-5: subscribe to EKF-filtered state instead of /ground_truth ──
        self.sub_filtered = self.create_subscription(
            Float32MultiArray, '/filtered_state', self._filtered_callback, 10)

        # Keep joint subscription for fallback velocity estimate
        self.sub_joints = self.create_subscription(
            JointState, '/joint_states', self.joint_callback, 10)

        self.pub = self.create_publisher(Float64, '/steering_angle', 10)

        # --- State ---
        self.pos_x    = 0.0
        self.pos_y    = 0.0
        self.yaw      = 0.0
        self.v_actual = 0.0
        self.tf_received = False

        # --- Stanley controller params ---
        self.wheel_radius  = 0.05
        self.k_lane        = 1.0    # Stanley gain
        self.alpha         = 0.8    # smoothing factor
        self.previous_delta = 0.0
        self.max_steer     = 0.8

        self.current_error     = 0.0
        self.current_steer_cmd = 0.0

        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.print_timer   = self.create_timer(0.5, self.print_status)

    # ─────────────────────────────────────────
    #  Callbacks
    # ─────────────────────────────────────────
    def _filtered_callback(self, msg: Float32MultiArray):
        """Receive EKF-filtered [x, y, theta, v] from Localization node."""
        if len(msg.data) >= 4:
            self.pos_x    = msg.data[0]
            self.pos_y    = msg.data[1]
            self.yaw      = msg.data[2]
            self.v_actual = msg.data[3]
            self.tf_received = True

    def wp_callback(self, msg):
        self.target_wp = msg

    def joint_callback(self, msg):
        """Fallback velocity from wheel encoder (used if filtered_state unavailable)."""
        try:
            if 'rear_left_wheel_joint' in msg.name:
                idx = msg.name.index('rear_left_wheel_joint')
                # Only override if we haven't received filtered state yet
                if not self.tf_received:
                    self.v_actual = msg.velocity[idx] * self.wheel_radius
        except ValueError:
            pass

    # ─────────────────────────────────────────
    #  Utility
    # ─────────────────────────────────────────
    def normalize_angle(self, angle):
        return (angle + math.pi) % (2 * math.pi) - math.pi

    # ─────────────────────────────────────────
    #  Stanley lateral control loop
    # ─────────────────────────────────────────
    def control_loop(self):
        if not self.tf_received:
            return

        mode      = self.get_parameter('mode').value
        raw_delta = 0.0

        if mode == 'lane':
            # 1. Heading error (θ_e)
            dx      = self.target_wp.x - self.pos_x
            dy      = self.target_wp.y - self.pos_y
            yaw_ref = math.atan2(dy, dx)
            theta_e = self.normalize_angle(yaw_ref - self.yaw)

            # 2. Cross-track error (e)  – lateral offset from waypoint y
            self.current_error = -(self.pos_y - self.target_wp.y)

            # 3. Stanley formula
            v_safe    = max(abs(self.v_actual), 0.1)
            raw_delta = theta_e + math.atan2(self.k_lane * self.current_error, v_safe)

        # Smooth + clamp
        delta = self.alpha * raw_delta + (1 - self.alpha) * self.previous_delta
        self.previous_delta = delta
        delta = max(-self.max_steer, min(self.max_steer, delta))
        self.current_steer_cmd = delta

        msg      = Float64()
        msg.data = float(delta)
        self.pub.publish(msg)

    def print_status(self):
        if self.tf_received:
            self.get_logger().info(
                f'[LATERAL] Target WP=({self.target_wp.x:.2f},{self.target_wp.y:.2f}) | '
                f'Pos=({self.pos_x:.2f},{self.pos_y:.2f}) | '
                f'Yaw={math.degrees(self.yaw):.1f}° | '
                f'CTE={self.current_error:.3f} m | '
                f'Steer={math.degrees(self.current_steer_cmd):.1f}°'
            )


def main(args=None):
    rclpy.init(args=args)
    node = HybridLateralControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
