import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Point
import csv
import os
import heapq
import math

class DijkstraPlanningNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_4_Planning_Team_5')
        self.declare_parameter('map', 'empty')
        self.map_type = self.get_parameter('map').value
        
        self.waypoints = self.run_dijkstra(self.map_type)
        self.save_to_excel(self.map_type)

        self.pub_speed = self.create_publisher(Float64, '/desired_velocity', 10)
        self.pub_wp    = self.create_publisher(Point,   '/current_waypoint', 10)

        # ── MS-5: subscribe to EKF-filtered state ──
        self.sub_filtered = self.create_subscription(
            Float32MultiArray, '/filtered_state', self._filtered_callback, 10)
        
        # ── State Variables ──
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.pos_yaw = 0.0
        self.pos_v = 0.0
        self.tf_received = False
        
        self.actual_path = []
        self.saved_actual_path = False
        
        # ── Telemetry Logging Arrays for Graph Generator ──
        self.log_v = []
        self.log_x = []
        self.log_y = []
        self.log_yaw = []
        self.start_time = None
        
        self.timer = self.create_timer(0.1, self.planning_loop)

    # ─────────────────────────────────────────
    #  Callback – filtered state [x, y, theta, v]
    # ─────────────────────────────────────────
    def _filtered_callback(self, msg: Float32MultiArray):
        if len(msg.data) >= 4:
            self.pos_x = float(msg.data[0])
            self.pos_y = float(msg.data[1])
            self.pos_yaw = float(msg.data[2])
            self.pos_v = float(msg.data[3])
            self.tf_received = True

    # ─────────────────────────────────────────
    #  CSV exporters
    # ─────────────────────────────────────────
    def save_telemetry_csvs(self):
        base_path = os.path.expanduser('~/Autonomous_project')
        
        try:
            # 1. velocity.csv
            with open(os.path.join(base_path, 'velocity.csv'), mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['time', 'v_state', 'v_ref'])
                writer.writerows(self.log_v)
                
            # 2. x.csv
            with open(os.path.join(base_path, 'x.csv'), mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['time', 'x_state', 'x_ref'])
                writer.writerows(self.log_x)
                
            # 3. y.csv
            with open(os.path.join(base_path, 'y.csv'), mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['time', 'y_state', 'y_ref'])
                writer.writerows(self.log_y)
                
            # 4. yaw.csv
            with open(os.path.join(base_path, 'yaw.csv'), mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['time', 'yaw_state', 'yaw_ref'])
                writer.writerows(self.log_yaw)
                
            self.get_logger().info('✅ Telemetry saved: velocity.csv, x.csv, y.csv, yaw.csv')
        except Exception as e:
            self.get_logger().error(f'Telemetry CSV write error: {e}')

    def save_graph_to_csv(self, graph, map_type):
        filename = os.path.expanduser(f'~/Autonomous_project/graph_edges_{map_type}.csv')
        try:
            with open(filename, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Start_X', 'Start_Y', 'End_X', 'End_Y', 'Cost'])
                for start_node, edges in graph.items():
                    for cost, end_node in edges:
                        writer.writerow([start_node[0], start_node[1], end_node[0], end_node[1], cost])
        except Exception as e:
            pass

    def save_to_excel(self, map_type):
        filename = os.path.expanduser(f'~/Autonomous_project/planned_path_{map_type}.csv')
        try:
            with open(filename, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Node_X', 'Node_Y'])
                writer.writerows(self.waypoints)
        except Exception as e:
            pass
            
    def save_actual_path_to_csv(self):
        filename = os.path.expanduser(f'~/Autonomous_project/actual_path_{self.map_type}.csv')
        try:
            with open(filename, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Actual_X', 'Actual_Y'])
                writer.writerows(self.actual_path)
            self.get_logger().info(f'Actual path saved → {filename}')
        except Exception as e:
            pass

    # ─────────────────────────────────────────
    #  Dijkstra / Path Generation
    # ─────────────────────────────────────────
    def run_dijkstra(self, map_type):
        step = 0.5
        if map_type == 'empty':
            self.get_logger().info('Map: Empty Track')
            path = [[float(i * step), 0.0] for i in range(int(10/step) + 1)]
            graph = {}
            for i in range(len(path) - 1):
                graph[tuple(path[i])] = [(step, tuple(path[i+1]))]
            self.save_graph_to_csv(graph, 'empty')
            return path
            
        elif map_type == 'racing':
            self.get_logger().info('Map: Racing Track')
            x_steps   = [float(i * step) for i in range(1, int(10/step) + 1)]
            y_lanes   = [0.1875, -0.1875]
            obstacles = [(4.0, 0.1875), (6.0, -0.1875)]
            graph = {}
            start = (0.0, 0.0)
            graph[start] = [(math.hypot(step, 0.1875), (step, 0.1875))]
            for x in x_steps:
                for y in y_lanes:
                    if (x, y) not in obstacles:
                        graph[(x, y)] = []
                        if x < 10.0:
                            next_x = x + step
                            for next_y in y_lanes:
                                if (next_x, next_y) not in obstacles:
                                    if y != next_y:
                                        obs_dist = 999.0
                                        for ox, oy in obstacles:
                                            if oy == y and ox > x:
                                                obs_dist = min(obs_dist, ox - x)
                                        if obs_dist > 1.5: continue
                                    dist = math.hypot(next_x - x, next_y - y)
                                    lane_penalty = 0.8 if y != next_y else 0.0
                                    graph[(x, y)].append((dist + lane_penalty, (next_x, next_y)))
            self.save_graph_to_csv(graph, 'racing')
            queue   = [(0.0, start, [start])]
            visited = set()
            while queue:
                cost, current, path = heapq.heappop(queue)
                if current in visited: continue
                visited.add(current)
                if current[0] >= 10.0:
                    if current[1] != 0.0: path.append((10.0, 0.0))
                    return path
                for edge_cost, neighbor in graph.get(current, []):
                    if neighbor not in visited:
                        heapq.heappush(queue, (cost + edge_cost, neighbor, path + [neighbor]))
            return [[0.0, 0.0], [10.0, 0.0]]

        elif map_type == 'city':
            self.get_logger().info('Map: City Track')
            path = []
            for i in range(0, 7):  path.append([0.0 + (i * 0.25), -0.10])
            for a in range(285, 360, 15):
                path.append([1.5 + 0.85*math.cos(math.radians(a)), 0.75 + 0.85*math.sin(math.radians(a))])
            for i in range(0, 9):  path.append([2.35, 0.75 + (i * 0.25)])
            for a in range(15, 91, 15):
                path.append([1.5 + 0.85*math.cos(math.radians(a)), 2.75 + 0.85*math.sin(math.radians(a))])
            for i in range(1, 12): path.append([1.5 - (i * 0.25), 3.60])
            for a in range(90, 181, 15):
                path.append([-1.3 + 0.80*math.cos(math.radians(a)), 2.80 + 0.80*math.sin(math.radians(a))])
            for i in range(1, 9):  path.append([-2.10, 2.80 - (i * 0.25)])
            for a in range(180, 271, 15):
                path.append([-1.3 + 0.80*math.cos(math.radians(a)), 0.70 + 0.80*math.sin(math.radians(a))])
            for i in range(1, 6):  path.append([-1.5 + (i * 0.25), -0.10])
            graph = {}
            for i in range(len(path) - 1):
                curr = tuple(path[i]); nxt = tuple(path[i+1])
                dist = math.hypot(nxt[0]-curr[0], nxt[1]-curr[1])
                graph[curr] = [(dist, nxt)]
            self.save_graph_to_csv(graph, 'city')
            return path
        
        # Default fallback
        return [[0.0, 0.0], [10.0, 0.0]]

    # ─────────────────────────────────────────
    #  Planning loop
    # ─────────────────────────────────────────
    def planning_loop(self):
        if not self.tf_received: return

        now_sec = self.get_clock().now().nanoseconds / 1e9
        if self.start_time is None:
            self.start_time = now_sec
        t = now_sec - self.start_time

        if not hasattr(self, 'started_lap'):
            min_dist = float('inf'); idx = 0
            for i, wp in enumerate(self.waypoints):
                d = math.hypot(wp[0]-self.pos_x, wp[1]-self.pos_y)
                if d < min_dist: min_dist, idx = d, i
            self.current_wp_idx = idx
            self.started_lap    = True
            self.waypoints_passed  = 0
            self.total_waypoints   = len(self.waypoints)
            self.get_logger().info(f'Tracking started at Waypoint {idx}')

        target = self.waypoints[self.current_wp_idx]
        dist   = math.hypot(target[0] - self.pos_x, target[1] - self.pos_y)
        
        dist_threshold = 0.25 if self.map_type in ['city', 'figure8'] else 0.5
        
        if dist < dist_threshold:
            if self.map_type in ['empty', 'racing']:
                # Straight tracks lock onto the last waypoint (no wrapping)
                self.current_wp_idx = min(self.current_wp_idx + 1, self.total_waypoints - 1)
            else:
                # Laps and closed tracks loop around
                self.current_wp_idx = (self.current_wp_idx + 1) % self.total_waypoints
                
            self.waypoints_passed += 1

        self.actual_path.append([self.pos_x, self.pos_y])

        target_v   = 0.3
        finished_lap = False
        
        if self.map_type == 'city':
            if self.waypoints_passed >= self.total_waypoints:
                target_v = 0.0; finished_lap = True
        else:
            if self.pos_x >= 10.0:
                target_v = 0.0; finished_lap = True
                
        # ── TELEMETRY LOGGING ──
        if self.started_lap and not finished_lap:
            # Calculate Reference Yaw (tangent angle between previous and current waypoint)
            prev_idx = (self.current_wp_idx - 1) % self.total_waypoints
            prev_wp = self.waypoints[prev_idx]
            yaw_ref = math.atan2(target[1] - prev_wp[1], target[0] - prev_wp[0])
            
            # Append data row [time, state, ref]
            self.log_x.append([t, self.pos_x, target[0]])
            self.log_y.append([t, self.pos_y, target[1]])
            self.log_yaw.append([t, self.pos_yaw, yaw_ref])
            self.log_v.append([t, self.pos_v, target_v])

        # ── FINISH LAP: SAVE ALL FILES ──
        if finished_lap and not self.saved_actual_path:
            self.save_actual_path_to_csv()
            self.save_telemetry_csvs()  # Dumps the 4 files for the Graph Generator
            self.saved_actual_path = True
        
        msg_v       = Float64(); msg_v.data = float(target_v)
        self.pub_speed.publish(msg_v)

        msg_wp = Point()
        if finished_lap:
            msg_wp.x = 10.0
            msg_wp.y = 0.1875 if self.map_type == 'racing' else 0.0
        else:
            msg_wp.x = float(self.waypoints[self.current_wp_idx][0])
            msg_wp.y = float(self.waypoints[self.current_wp_idx][1])
        self.pub_wp.publish(msg_wp)

def main(args=None):
    rclpy.init(args=args)
    node = DijkstraPlanningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
