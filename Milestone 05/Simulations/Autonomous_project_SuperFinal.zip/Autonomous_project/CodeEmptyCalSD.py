import pandas as pd
import numpy as np
import os

def calculate_track_stats(planned_csv, actual_csv, track_name):
    try:
        df_p = pd.read_csv(planned_csv)
        df_a = pd.read_csv(actual_csv)

        # --- AUTO-DETECT COLUMNS ---
        # Look for X and Y in the Actual file
        cols = df_a.columns.tolist()
        x_col = next((c for c in cols if 'x' in c.lower()), None)
        y_col = next((c for c in cols if 'y' in c.lower()), None)

        if not x_col or not y_col:
            print(f"❌ {track_name}: Found columns {cols}, but need X and Y.")
            return

        # --- CALCULATION ---
        errors_y = []
        for _, row in df_a.iterrows():
            # Match actual X to planned path
            target_y = np.interp(row[x_col], df_p['Node_X'], df_p['Node_Y'])
            errors_y.append(row[y_col] - target_y)

        print(f"✅ {track_name} (using columns: {x_col}, {y_col})")
        print(f"   Standard Deviation (σ): {np.std(errors_y):.4f} m")
        print(f"   Max Tracking Error:     {np.max(np.abs(errors_y)):.4f} m\n")
        
    except Exception as e:
        print(f"❌ Could not process {track_name}: {e}")

# Run for your files
calculate_track_stats('planned_path_empty.csv', 'actual_path_empty.csv', 'Empty Track')
calculate_track_stats('planned_path_racing.csv', 'actual_path_racing.csv', 'Racing Track')
calculate_track_stats('planned_path_city.csv', 'actual_path_city.csv', 'City Track')