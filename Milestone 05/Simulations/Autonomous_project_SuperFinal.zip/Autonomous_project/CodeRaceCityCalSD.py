import pandas as pd
import numpy as np
import os

def calculate_track_stats(planned_csv, actual_csv, track_name):
    if not os.path.exists(planned_csv) or not os.path.exists(actual_csv):
        return

    try:
        df_p = pd.read_csv(planned_csv)
        df_a = pd.read_csv(actual_csv)

        # --- UPDATED COLUMN DETECTION ---
        # Look for columns containing 'x' and 'y' (handles 'Actual_X', 'x', 'X', etc.)
        cols = df_a.columns.tolist()
        x_col = next((c for c in cols if 'x' in c.lower()), None)
        y_col = next((c for c in cols if 'y' in c.lower()), None)

        if not x_col or not y_col:
            print(f"❌ {track_name}: Could not find X/Y columns in {cols}")
            return

        # Convert to numpy arrays
        # Planned path: Node_X, Node_Y | Actual path: detected cols
        planned_pts = df_p[['Node_X', 'Node_Y']].values
        actual_pts = df_a[[x_col, y_col]].values

        # --- EUCLIDEAN CALCULATION (Shortest distance to path) ---
        errors = []
        for a_pt in actual_pts:
            # Distance from current point to all points on the planned trajectory
            distances = np.linalg.norm(planned_pts - a_pt, axis=1)
            # Shortest distance is the true tracking error
            errors.append(np.min(distances))

        errors = np.array(errors)

        print(f"✅ {track_name} (using: {x_col}, {y_col})")
        print(f"   Standard Deviation (σ): {np.std(errors):.4f} m")
        print(f"   Max Tracking Error:     {np.max(errors):.4f} m\n")
        
    except Exception as e:
        print(f"❌ Could not process {track_name}: {e}")

# Run for your files
calculate_track_stats('planned_path_empty.csv', 'actual_path_empty.csv', 'Empty Track')
calculate_track_stats('planned_path_racing.csv', 'actual_path_racing.csv', 'Racing Track')
calculate_track_stats('planned_path_city.csv', 'actual_path_city.csv', 'City Track')
