import pandas as pd
import matplotlib.pyplot as plt
import os

# The three tracks we want to graph
tracks = ['empty', 'racing', 'city']

for map_type in tracks:
    planned_file = os.path.expanduser(f'~/Autonomous_project/planned_path_{map_type}.csv')
    actual_file = os.path.expanduser(f'~/Autonomous_project/actual_path_{map_type}.csv')

    # Check if the car has actually driven this track yet
    if not os.path.exists(planned_file) or not os.path.exists(actual_file):
        print(f"⚠️ Skipping {map_type.capitalize()} Track: Missing CSV files. Did you run the car to the finish line?")
        continue

    # Load the data
    planned_df = pd.read_csv(planned_file)
    actual_df = pd.read_csv(actual_file)

    # Create a wide, clean canvas
    plt.figure(figsize=(12, 5))

    # Plot the TARGETED path (Blue Dashed)
    plt.plot(planned_df['Node_X'], planned_df['Node_Y'], 
             linestyle='--', color='blue', linewidth=2, label='Targeted Path (Planned)')

    # Plot the ACTUAL path (Red Solid)
    plt.plot(actual_df['Actual_X'], actual_df['Actual_Y'], 
             linestyle='-', color='red', linewidth=2, label='Actual Path (Driven)')

    # Draw specific track features
    if map_type == 'racing':
        plt.axhline(y=0.1875, color='gray', linestyle=':', label='Lane 1')
        plt.axhline(y=-0.1875, color='gray', linestyle=':', label='Lane 2')
        plt.scatter([4.0, 6.0], [0.1875, -0.1875], color='black', marker='X', s=100, label='Obstacles')
    elif map_type == 'empty':
        plt.axhline(y=0.0, color='gray', linestyle=':', label='Center Line')

    # Formatting to make it look professional
    plt.title(f'Tracking Performance: {map_type.capitalize()} Track', fontsize=16, fontweight='bold')
    plt.xlabel('X Coordinate (meters)', fontsize=12)
    plt.ylabel('Y Coordinate (meters)', fontsize=12)
    plt.legend(loc='best')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.axis('equal') # Forces the X and Y scale to be visually accurate

    # Save the file automatically as a high-quality PNG
    save_path = os.path.expanduser(f'~/Autonomous_project/comparison_graph_{map_type}.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close() # Close the graph so the next one can be drawn
    
    print(f"✅ Saved perfectly formatted graph for {map_type.capitalize()} Track to: {save_path}")