# stanley_node_aut.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import math
import numpy as np

class StanleyNode(Node):
    def __init__(self):
        super().__init__('stanley_node_aut')

        self.sub_state = self.create_subscription(Float32MultiArray,'/state',self.state_callback,10)
        
        self.sub_ref = self.create_subscription(Float32MultiArray, '/reference', self.ref_callback, 10)

        self.sub_pwm = self.create_subscription(Float32MultiArray, '/pwm_cmd', self.pwm_callback, 10)

        self.pub = self.create_publisher(Float32MultiArray, '/steering_cmd', 10)

        self.x_ref = 0.0
        self.y_ref = 0.0
        self.yaw_ref = 0.0
        self.pwm_motor = 0
        self.previous_delta=0
        
        self.max_steer_rad=math.radians(50.0)
        self.alpha=1
        self.k = 1.2
        self.epsilon = 0.05

    def ref_callback(self, msg):
        self.x_ref = msg.data[0]
        #self.x_ref=1
        self.y_ref = msg.data[1]
        #self.y_ref=2
        self.yaw_ref = msg.data[2]
        #self.yaw_ref=0

    def pwm_callback(self, msg):
        self.pwm_motor = int(msg.data[0])
        #self.pwm_motor=0

    def state_callback(self, msg):
        x=msg.data[0]
        #x=1
        y = msg.data[1]
        #y=2
        yaw = msg.data[2]
        v = msg.data[3]

        self.yaw_ref=normalize_angle(self.yaw_ref)

        dx = self.x_ref - x
        dy = (self.y_ref - y)*1

        theta_e = normalize_angle(self.yaw_ref - yaw)

        e_y = -math.sin(yaw)*dx + math.cos(yaw)*dy 

        #self.get_logger().info(f"Cross track error: {e_y}")

        #self.get_logger().info(f"Heading error: {theta_e}")  

        # Avoid division by zero
        v_safe = v+self.epsilon

        # Add a low pass filter
        previous_delta_filtered=(1-self.alpha) * self.previous_delta

        # Full Stanley formula with low pass filtering
        delta_raw=  theta_e + math.atan2(self.k * e_y, v_safe)
        delta_raw = normalize_angle(delta_raw)  # ✅ keep delta in valid range
        delta_raw = max(-self.max_steer_rad, min(self.max_steer_rad, delta_raw))
        delta = self.alpha * delta_raw + previous_delta_filtered

        # Update previous_delta
        self.previous_delta=delta
        
        delta_deg = math.degrees(delta)
        delta_deg = max(-50, min(50, delta_deg))

        # Map to servo [0,180]
        servo_angle = delta_deg + 90

        msg_out = Float32MultiArray()
        msg_out.data = [servo_angle, float(self.pwm_motor)]
        self.pub.publish(msg_out)

def normalize_angle(angle):
    return (angle + np.pi) % (2*np.pi) - np.pi

def main(args=None):
    rclpy.init(args=args)
    node = StanleyNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

