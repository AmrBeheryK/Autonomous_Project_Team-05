import launch
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch.conditions import LaunchConfigurationEquals
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # 1. Declare the Launch Arguments so the terminal can talk to them
    mode_arg = DeclareLaunchArgument(
        'mode',
        default_value='olr',
        description='Driving mode: "olr" or "teleop"'
    )
    
    vel_arg = DeclareLaunchArgument(
        'desired_velocity',
        default_value='3.0',
        description='Target velocity for OLR'
    )
    
    steer_arg = DeclareLaunchArgument(
        'desired_steering',
        default_value='-0.2',
        description='Target steering angle for OLR'
    )

    # Gazebo Empty World
    gazebo_pkg_dir = get_package_share_directory('gazebo_ackermann_steering_vehicle')
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_pkg_dir, 'launch', 'vehicle.launch.py')
        ),
        launch_arguments={'x': '0.0', 'y': '0.0', 'z': '0.5'}.items()
    )

    # OLR Node
    olr_node = Node(
        package='autonomous_systems_project_team_5',
        executable='Autonomous_Systems_MS_2_OLR_Team_5',
        output='screen',
        # 2. Link the terminal arguments to the node parameters dynamically
        parameters=[{
            'desired_velocity': LaunchConfiguration('desired_velocity'),
            'desired_steering': LaunchConfiguration('desired_steering')
        }],
        condition=LaunchConfigurationEquals('mode', 'olr')
    )

    # Teleop Node
    teleop_node = Node(
        package='autonomous_systems_project_team_5',
        executable='Autonomous_Systems_MS_2_Teleop_Team_5',
        output='screen',
        prefix='xterm -hold -e ', 
        condition=LaunchConfigurationEquals('mode', 'teleop')
    )

    # rqt_graph Node
    rqt_graph_node = Node(
        package='rqt_graph',
        executable='rqt_graph',
        name='rqt_graph'
    )

    # 3. Add the new arguments to the final LaunchDescription
    return LaunchDescription([
        mode_arg,
        vel_arg,
        steer_arg,
        gazebo_launch,
        olr_node,
        teleop_node,
        rqt_graph_node
    ])
