import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch.conditions import IfCondition
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    map_arg = DeclareLaunchArgument('map', default_value='empty', description="Choose track: 'empty', 'racing', or 'city'")
    
    # Clean default spawn locations
    init_x_arg = DeclareLaunchArgument('init_x', default_value='0.0')
    init_y_arg = DeclareLaunchArgument('init_y', default_value='0.0')
    init_yaw_arg = DeclareLaunchArgument('init_yaw', default_value='0.0')

    map_conf = LaunchConfiguration('map')

    worlds_dir = os.path.expanduser('~/Autonomous_project/src/autonomous_systems_project_team_5/Worlds')
    
    world_file = PythonExpression([
        "'", worlds_dir, "/Empty_Track.world' if '", map_conf, "' == 'empty' else ",
        "'", worlds_dir, "/Racing_Track.world' if '", map_conf, "' == 'racing' else ",
        "'", worlds_dir, "/City_Track.world'"
    ])

    gazebo_pkg_dir = get_package_share_directory('gazebo_ackermann_steering_vehicle')
    spawn_vehicle = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_pkg_dir, 'launch', 'vehicle.launch.py')),
        launch_arguments={
            'x': LaunchConfiguration('init_x'), 
            'y': LaunchConfiguration('init_y'), 
            'z': '0.5', 
            'yaw': LaunchConfiguration('init_yaw'),
            'world': world_file
        }.items()
    )

    bridge_empty = Node(
        condition=IfCondition(PythonExpression(["'", map_conf, "' == 'empty'"])),
        package='ros_gz_bridge', executable='parameter_bridge',
        arguments=['/world/Empty_Track/dynamic_pose/info@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'],
        remappings=[('/world/Empty_Track/dynamic_pose/info', '/ground_truth')]
    )

    bridge_racing = Node(
        condition=IfCondition(PythonExpression(["'", map_conf, "' == 'racing'"])),
        package='ros_gz_bridge', executable='parameter_bridge',
        arguments=['/world/Racing_Track/dynamic_pose/info@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'],
        remappings=[('/world/Racing_Track/dynamic_pose/info', '/ground_truth')]
    )

    bridge_city = Node(
        condition=IfCondition(PythonExpression(["'", map_conf, "' == 'city'"])),
        package='ros_gz_bridge', executable='parameter_bridge',
        arguments=['/world/City_Track/dynamic_pose/info@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'],
        remappings=[('/world/City_Track/dynamic_pose/info', '/ground_truth')]
    )

    speed_node = Node(
        package='autonomous_systems_project_team_5', 
        executable='Autonomous_Systems_MS_3_CLR_Alg_1_Speed_Team_5', 
        output='screen'
    )

    lateral_node = Node(
        package='autonomous_systems_project_team_5', 
        executable='Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_5', 
        output='screen',
        parameters=[{'mode': 'lane'}] 
    )

    planning_node = Node(
        package='autonomous_systems_project_team_5', 
        executable='Autonomous_Systems_MS_4_Planning_Team_5', 
        output='screen',
        parameters=[{'map': map_conf}]
    )

    rqt_graph_node = ExecuteProcess(cmd=['rqt_graph'], output='screen')

    return LaunchDescription([
        map_arg, init_x_arg, init_y_arg, init_yaw_arg,
        spawn_vehicle, 
        bridge_empty, bridge_racing, bridge_city,
        speed_node, lateral_node, planning_node, rqt_graph_node
    ])
