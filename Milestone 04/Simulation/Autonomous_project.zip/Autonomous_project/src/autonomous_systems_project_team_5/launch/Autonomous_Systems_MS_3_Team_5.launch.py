import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch.conditions import IfCondition
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # --- The Master Mode Argument ---
    mode_arg = DeclareLaunchArgument('mode', default_value='lane', description="Tracking mode: 'lane' or 'goal'")
    
    # --- Variables ---
    vel_arg = DeclareLaunchArgument('desired_velocity', default_value='1.5')
    lane_arg = DeclareLaunchArgument('desired_lateral_distance', default_value='3.0')
    lane_yaw_arg = DeclareLaunchArgument('lane_yaw', default_value='0.0') 
    goal_x_arg = DeclareLaunchArgument('goal_x', default_value='10.0')
    goal_y_arg = DeclareLaunchArgument('goal_y', default_value='10.0')
    init_x_arg = DeclareLaunchArgument('init_x', default_value='0.0')
    init_y_arg = DeclareLaunchArgument('init_y', default_value='0.0')
    init_yaw_arg = DeclareLaunchArgument('init_yaw', default_value='0.0')

    gazebo_pkg_dir = get_package_share_directory('gazebo_ackermann_steering_vehicle')
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_pkg_dir, 'launch', 'vehicle.launch.py')),
        launch_arguments={'x': LaunchConfiguration('init_x'), 'y': LaunchConfiguration('init_y'), 'z': '0.5', 'yaw': LaunchConfiguration('init_yaw')}.items()
    )

    # Spawn Lane ONLY if mode == 'lane'
    lane_sdf = '<?xml version="1.0" ?><sdf version="1.6"><model name="target_lane"><static>true</static><link name="link"><visual name="visual"><geometry><box><size>200 0.15 0.001</size></box></geometry><material><ambient>1 0.8 0 1</ambient><diffuse>1 0.8 0 1</diffuse></material></visual></link></model></sdf>'
    spawn_lane_node = Node(
        condition=IfCondition(PythonExpression(["'", LaunchConfiguration('mode'), "' == 'lane'"])),
        package='ros_gz_sim', executable='create',
        arguments=['-name', 'target_lane', '-string', lane_sdf, '-x', '0.0', '-y', LaunchConfiguration('desired_lateral_distance'), '-z', '0.01']
    )

    # Spawn Pillar ONLY if mode == 'goal'
    pillar_sdf = '<?xml version="1.0" ?><sdf version="1.6"><model name="target_pillar"><static>true</static><link name="link"><visual name="visual"><geometry><cylinder><radius>0.4</radius><length>2.5</length></cylinder></geometry><material><ambient>0 1 0 1</ambient><diffuse>0 1 0 1</diffuse></material></visual></link></model></sdf>'
    spawn_pillar_node = Node(
        condition=IfCondition(PythonExpression(["'", LaunchConfiguration('mode'), "' == 'goal'"])),
        package='ros_gz_sim', executable='create',
        arguments=['-name', 'target_pillar', '-string', pillar_sdf, '-x', LaunchConfiguration('goal_x'), '-y', LaunchConfiguration('goal_y'), '-z', '1.25']
    )

    ground_truth_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/world/empty/dynamic_pose/info@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'],
        remappings=[('/world/empty/dynamic_pose/info', '/ground_truth')]
    )

    speed_node = Node(
        package='autonomous_systems_project_team_5', executable='Autonomous_Systems_MS_3_CLR_Alg_1_Speed_Team_5', output='screen',
        parameters=[{'desired_velocity': LaunchConfiguration('desired_velocity')}]
    )

    lateral_node = Node(
        package='autonomous_systems_project_team_5', executable='Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_5', output='screen',
        parameters=[
            {'mode': LaunchConfiguration('mode')},
            {'desired_lateral_distance': LaunchConfiguration('desired_lateral_distance')},
            {'lane_yaw': LaunchConfiguration('lane_yaw')},
            {'goal_x': LaunchConfiguration('goal_x')},
            {'goal_y': LaunchConfiguration('goal_y')}
        ]
    )

    rqt_graph_node = ExecuteProcess(
        cmd=['rqt_graph'],
        output='screen'
    )

    return LaunchDescription([
        mode_arg, vel_arg, lane_arg, lane_yaw_arg, goal_x_arg, goal_y_arg, init_x_arg, init_y_arg, init_yaw_arg, 
        gazebo_launch, spawn_lane_node, spawn_pillar_node, ground_truth_bridge, speed_node, lateral_node, rqt_graph_node
    ])
