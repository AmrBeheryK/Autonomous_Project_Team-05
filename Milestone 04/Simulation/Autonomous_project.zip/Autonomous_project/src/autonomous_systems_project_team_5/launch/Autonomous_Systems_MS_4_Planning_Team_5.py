import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from tf2_msgs.msg import TFMessage
import csv
import os
from datetime import datetime

class PlanningNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_4_Planning_Team_5')
        self.declare_parameter('map', 'empty')
        
        # Publishers to tell the controllers what to do
        self.pub_speed = self.create_publisher(Float64, '/desired_velocity', 10)
        self.pub_lane = self.create_publisher(Float64, '/desired_lane', 10)
        
        # Subscriber to know exactly where the car is
        self.sub_tf = self.create_subscription(TFMessage, '/ground_truth', self.tf_callback, 10)
        
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.tf_received = False
        self.saved_csv = False
        self.trajectory_data = [] # List to store our Excel data
        
        self.timer = self.create_timer(0.1, self.planning_loop)

    def tf_callback(self, msg):
        if not msg.transforms: return
        transform = msg.transforms[0]
        self.pos_x = transform.transform.translation.x
        self.pos_y = transform.transform.translation.y
        self.tf_received = True
        
        # Record data 10 times a second while driving
        if not self.saved_csv:
            self.trajectory_data.append([self.pos_x, self.pos_y])

    def planning_loop(self):
        if not self.tf_received: return
        
        map_type = self.get_parameter('map').value
        target_v = 1.5
        target_lane = 0.0
        
        # --- Empty Track Logic ---
        if map_type == 'empty':
            if self.pos_x >= 10.0:
                target_v = 0.0  # STOP THE CAR
                if not self.saved_csv:
                    self.save_to_excel()
            else:
                target_v = 1.5  # DRIVE
                target_lane = 0.0
        
        # Publish commands to the controllers
        msg_v = Float64()
        msg_v.data = float(target_v)
        self.pub_speed.publish(msg_v)
        
        msg_l = Float64()
        msg_l.data = float(target_lane)
        self.pub_lane.publish(msg_l)
        
    def save_to_excel(self):
        # Saves the file to your Autonomous_project folder
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.expanduser(f'~/Autonomous_project/track_data_{timestamp}.csv')
        
        try:
            with open(filename, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['X_Position', 'Y_Position']) # Header Row
                writer.writerows(self.trajectory_data)        # Data Rows
            self.get_logger().info(f'✅ SUCCESS: Car Stopped! Excel file saved to: {filename}')
            self.saved_csv = True
        except Exception as e:
            self.get_logger().error(f'Failed to save CSV: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = PlanningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
