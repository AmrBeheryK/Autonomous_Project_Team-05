import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from tf2_msgs.msg import TFMessage
from geometry_msgs.msg import Point
import csv
import os
import heapq
import math

class DijkstraPlanningNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_4_Planning_Team_5')
        self.declare_parameter('map', 'empty')
        self.map_type = self.get_parameter('map').value
        
        # Generates paths AND saves the graph CSV for whichever map is chosen
        self.waypoints = self.run_dijkstra(self.map_type)
        
        # Saves the final waypoints to Excel
        self.save_to_excel(self.map_type)

        self.pub_speed = self.create_publisher(Float64, '/desired_velocity', 10)
        self.pub_wp = self.create_publisher(Point, '/current_waypoint', 10)
        self.sub_tf = self.create_subscription(TFMessage, '/ground_truth', self.tf_callback, 10)
        
        self.pos_x, self.pos_y = 0.0, 0.0
        self.tf_received = False
        
        self.timer = self.create_timer(0.1, self.planning_loop)

    def save_graph_to_csv(self, graph, map_type):
        """Saves any generated graph structure into an edge-list CSV."""
        filename = os.path.expanduser(f'~/Autonomous_project/graph_edges_{map_type}.csv')
        try:
            with open(filename, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Start_X', 'Start_Y', 'End_X', 'End_Y', 'Cost'])
                for start_node, edges in graph.items():
                    for cost, end_node in edges:
                        writer.writerow([start_node[0], start_node[1], end_node[0], end_node[1], cost])
            self.get_logger().info(f'🕸️ SUCCESS: Graph edges saved to {filename}')
        except Exception as e:
            self.get_logger().error(f'❌ GRAPH CSV WRITE ERROR: {str(e)}')

    def save_to_excel(self, map_type):
        """Saves the final calculated path waypoints into a CSV."""
        filename = os.path.expanduser(f'~/Autonomous_project/planned_path_{map_type}.csv')
        try:
            with open(filename, mode='w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Node_X', 'Node_Y'])
                writer.writerows(self.waypoints)
            self.get_logger().info(f'✅ SUCCESS: Waypoints saved to {filename}')
        except Exception as e:
            self.get_logger().error(f'❌ CSV WRITE ERROR: {str(e)}')

    def run_dijkstra(self, map_type):
        step = 0.5

        if map_type == 'empty':
            self.get_logger().info('🗺️ Map: Empty Track. Generating 0.5m step straight path.')
            path = [[float(i * step), 0.0] for i in range(int(10/step) + 1)]
            
            # Convert linear path to a graph dictionary so the CSV generator works
            graph = {}
            for i in range(len(path) - 1):
                graph[tuple(path[i])] = [(step, tuple(path[i+1]))]
            self.save_graph_to_csv(graph, 'empty')
            
            return path
            
        elif map_type == 'racing':
            self.get_logger().info('🗺️ Map: Racing Track. Running Obstacle Avoidance...')
            x_steps = [float(i * step) for i in range(1, int(10/step) + 1)]
            y_lanes = [0.1875, -0.1875]
            obstacles = [(4.0, 0.1875), (6.0, -0.1875)]
            
            graph = {}
            start = (0.0, 0.0)
            
            # Force start purely into Lane 1
            graph[start] = [(math.hypot(step, 0.1875), (step, 0.1875))]
            
            for x in x_steps:
                for y in y_lanes:
                    if (x, y) not in obstacles:
                        graph[(x, y)] = []
                        if x < 10.0:
                            next_x = x + step
                            for next_y in y_lanes:
                                if (next_x, next_y) not in obstacles:
                                    
                                    # LATE TURN LOGIC: Forbid early lane changes
                                    if y != next_y:
                                        obs_dist = 999.0
                                        # Calculate distance to upcoming obstacle in the CURRENT lane
                                        for ox, oy in obstacles:
                                            if oy == y and ox > x:
                                                obs_dist = min(obs_dist, ox - x)
                                        
                                        # Only allow a lane change if the obstacle is within 1.5m (3 steps)
                                        if obs_dist > 1.5:
                                            continue
                                            
                                    dist = math.hypot(next_x - x, next_y - y)
                                    lane_penalty = 0.8 if y != next_y else 0.0
                                    graph[(x, y)].append((dist + lane_penalty, (next_x, next_y)))
            
            # THIS MUST BE OUTSIDE THE FOR LOOPS (Fixed Indentation)
            self.save_graph_to_csv(graph, 'racing')
            
            queue = [(0.0, start, [start])]
            visited = set()
            while queue:
                cost, current, path = heapq.heappop(queue)
                if current in visited: continue
                visited.add(current)
                if current[0] >= 10.0:
                    if current[1] != 0.0: path.append((10.0, 0.0))
                    return path
                for edge_cost, neighbor in graph.get(current, []):
                    if neighbor not in visited:
                        heapq.heappush(queue, (cost + edge_cost, neighbor, path + [neighbor]))
            return [[0.0, 0.0], [10.0, 0.0]]

        elif map_type == 'city':
            self.get_logger().info('🗺️ Map: City Track. Generating trajectory starting from Origin...')
            path = []
            
            # 1. Bottom Straight
            for i in range(0, 7): path.append([0.0 + (i * 0.25), -0.10])
            # 2. Bottom Right Curve
            for a in range(285, 360, 15):
                path.append([1.5 + 0.85*math.cos(math.radians(a)), 0.75 + 0.85*math.sin(math.radians(a))])
            # 3. Right Straight
            for i in range(0, 9): path.append([2.35, 0.75 + (i * 0.25)])
            # 4. Top Right Curve
            for a in range(15, 91, 15): 
                path.append([1.5 + 0.85*math.cos(math.radians(a)), 2.75 + 0.85*math.sin(math.radians(a))])
           # 5. Top Straight
            for i in range(1, 12): path.append([1.5 - (i * 0.25), 3.60])
           # 6. Top Left Curve 
            for a in range(90, 181, 15):
                path.append([-1.3 + 0.80*math.cos(math.radians(a)), 2.80 + 0.80*math.sin(math.radians(a))])
            # 7. Left Straight 
            for i in range(1, 9): path.append([-2.10, 2.80 - (i * 0.25)])
            # 8. Bottom Left Curve
            for a in range(180, 271, 15):
                path.append([-1.3 + 0.80*math.cos(math.radians(a)), 0.70 + 0.80*math.sin(math.radians(a))])
            # 9. Bottom Straight (Connects to spawn)
            for i in range(1, 6): path.append([-1.5 + (i * 0.25), -0.10])
            
            # Convert trajectory to a graph dictionary so the CSV generator works
            graph = {}
            for i in range(len(path) - 1):
                curr = tuple(path[i])
                nxt = tuple(path[i+1])
                dist = math.hypot(nxt[0]-curr[0], nxt[1]-curr[1])
                graph[curr] = [(dist, nxt)]
            self.save_graph_to_csv(graph, 'city')
            
            return path

    def tf_callback(self, msg):
        if not msg.transforms: return
        t = msg.transforms[0].transform.translation
        self.pos_x, self.pos_y = t.x, t.y
        self.tf_received = True

    def planning_loop(self):
        if not self.tf_received: return

        if not hasattr(self, 'started_lap'):
            min_dist = float('inf')
            idx = 0
            for i, wp in enumerate(self.waypoints):
                d = math.hypot(wp[0]-self.pos_x, wp[1]-self.pos_y)
                if d < min_dist:
                    min_dist, idx = d, i
            self.current_wp_idx = idx
            self.started_lap = True
            self.waypoints_passed = 0
            self.total_waypoints = len(self.waypoints)
            self.get_logger().info(f'🏎️ Tracking started at Waypoint {idx}')

        target = self.waypoints[self.current_wp_idx]
        dist = math.hypot(target[0] - self.pos_x, target[1] - self.pos_y)
        
        dist_threshold = 0.25 if self.map_type == 'city' else 0.5
        
        if dist < dist_threshold:
            self.current_wp_idx = (self.current_wp_idx + 1) % self.total_waypoints
            self.waypoints_passed += 1

        target_v = 0.6 
        if self.map_type == 'city':
            if self.waypoints_passed >= self.total_waypoints:
                target_v = 0.0
        else:
            if self.pos_x >= 10.0: target_v = 0.0
        
        msg_v = Float64(); msg_v.data = float(target_v); self.pub_speed.publish(msg_v)
        msg_wp = Point()
        msg_wp.x = float(self.waypoints[self.current_wp_idx][0])
        msg_wp.y = float(self.waypoints[self.current_wp_idx][1])
        self.pub_wp.publish(msg_wp)

def main(args=None):
    rclpy.init(args=args)
    node = DijkstraPlanningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
