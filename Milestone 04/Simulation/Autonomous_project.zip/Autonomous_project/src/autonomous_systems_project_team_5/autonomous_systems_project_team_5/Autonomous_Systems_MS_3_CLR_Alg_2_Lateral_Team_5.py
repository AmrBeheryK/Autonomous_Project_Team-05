import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from tf2_msgs.msg import TFMessage
from geometry_msgs.msg import Point  # Added for Waypoint support
import math

class HybridLateralControllerNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_3_CLR_Alg_2_Lateral_Team_5')
        
        # --- Mode Toggle ---
        self.declare_parameter('mode', 'lane') 
        
        # --- Parameters (Defaults) ---
        self.declare_parameter('lane_yaw', 0.0) 
        
        # --- Subscriber for Dijkstra Waypoints ---
        # The planner sends the next node in the Dijkstra path here
        self.sub_wp = self.create_subscription(Point, '/current_waypoint', self.wp_callback, 10)
        self.target_wp = Point() # Stores the X, Y from Dijkstra
        
        self.pub = self.create_publisher(Float64, '/steering_angle', 10)
        self.sub_joints = self.create_subscription(JointState, '/joint_states', self.joint_callback, 10)
        self.sub_tf = self.create_subscription(TFMessage, '/ground_truth', self.tf_callback, 10)
        
        # State Variables
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.yaw = 0.0
        self.v_actual = 0.0
        self.tf_received = False
        
        # Control Constants
        self.wheel_radius = 0.05
        self.k_lane = 1  # Stanley Gain
        self.alpha = 0.8   # Smoothing filter
        self.previous_delta = 0.0
        self.max_steer = 0.8
        
        self.current_error = 0.0
        self.current_steer_cmd = 0.0

        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.print_timer = self.create_timer(0.5, self.print_status)

    def wp_callback(self, msg):
        """Receives the next waypoint from the Dijkstra Planner"""
        self.target_wp = msg

    def normalize_angle(self, angle):
        return (angle + math.pi) % (2*math.pi) - math.pi

    def euler_from_quaternion(self, x, y, z, w):
        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        return math.atan2(t3, t4)

    def joint_callback(self, msg):
        try:
            if 'rear_left_wheel_joint' in msg.name:
                idx_vel = msg.name.index('rear_left_wheel_joint')
                self.v_actual = msg.velocity[idx_vel] * self.wheel_radius
        except ValueError:
            pass

    def tf_callback(self, msg):
        if not msg.transforms: return
        transform = msg.transforms[0]
        self.pos_x = transform.transform.translation.x
        self.pos_y = transform.transform.translation.y
        q = transform.transform.rotation
        self.yaw = self.euler_from_quaternion(q.x, q.y, q.z, q.w)
        self.tf_received = True

    def control_loop(self):
        if not self.tf_received: return 
            
        mode = self.get_parameter('mode').value
        raw_delta = 0.0
        
        if mode == 'lane':
            # --- STANLEY STEERING LOGIC FOR WAYPOINTS ---
            
            # 1. Heading Error (theta_e)
            # Calculate the angle toward the Dijkstra waypoint
            dx = self.target_wp.x - self.pos_x
            dy = self.target_wp.y - self.pos_y
            yaw_ref = math.atan2(dy, dx)
            theta_e = self.normalize_angle(yaw_ref - self.yaw)
            
            # 2. Cross-track Error (e)
            # Distance from the center line (Y-axis target from waypoint)
            self.current_error = -(self.pos_y - self.target_wp.y)
            
            # 3. Stanley Formula
            v_safe = max(abs(self.v_actual), 0.1)
            raw_delta = theta_e + math.atan2(self.k_lane * self.current_error, v_safe)
            
        # --- SMOOTHING & OUTPUT ---
        delta = self.alpha * raw_delta + (1 - self.alpha) * self.previous_delta
        self.previous_delta = delta
        
        # Clamp steering to physical limits
        delta = max(-self.max_steer, min(self.max_steer, delta))
        self.current_steer_cmd = delta
        
        msg = Float64()
        msg.data = float(delta) 
        self.pub.publish(msg)
        
    def print_status(self):
        if self.tf_received:
            self.get_logger().info(
                f'[DIJKSTRA FOLLOW] Target: ({self.target_wp.x:.1f}, {self.target_wp.y:.1f}) | '
                f'Pos: ({self.pos_x:.1f}, {self.pos_y:.1f}) | Error: {self.current_error:.3f}'
            )

def main(args=None):
    rclpy.init(args=args)
    node = HybridLateralControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
