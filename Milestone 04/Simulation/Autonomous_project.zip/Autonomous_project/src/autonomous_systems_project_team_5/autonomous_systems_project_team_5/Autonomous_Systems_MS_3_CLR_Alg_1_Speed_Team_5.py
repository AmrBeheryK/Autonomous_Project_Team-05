import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
import time

class SpeedControllerNode(Node):
    def __init__(self):
        super().__init__('Autonomous_Systems_MS_3_CLR_Alg_1_Speed_Team_5')
        
        # Listen to the new Planner node for speed commands!
        self.sub_vel = self.create_subscription(Float64, '/desired_velocity', self.velocity_callback, 10)
        self.target_speed = 0.0 # Default starting speed
        
        self.pub = self.create_publisher(Float64, '/velocity', 10)
        self.sub = self.create_subscription(JointState, '/joint_states', self.state_callback, 10)
        
        # Heavily damped PID to prevent jerking the 0-inertia model
        self.Kp = 0.5 
        self.Ki = 0.05
        self.Kd = 0.01
        
        self.integral = 0.0
        self.prev_error = 0.0
        self.last_time = time.time()
        
        self.v_actual = 0.0
        self.v_cmd = 0.0
        self.v_max = 2.0 # Cap max speed to keep physics stable
        
        self.control_timer = self.create_timer(0.1, self.compute_control)
        self.print_timer = self.create_timer(0.5, self.print_status)

    def velocity_callback(self, msg):
        self.target_speed = msg.data

    def state_callback(self, msg):
        try:
            if 'rear_left_wheel_joint' in msg.name:
                idx_vel = msg.name.index('rear_left_wheel_joint')
                self.v_actual = msg.velocity[idx_vel] * 0.05
        except ValueError:
            pass
            
    def compute_control(self):
        v_ref = self.target_speed  # Now correctly uses the speed from the planner
        now = time.time()
        dt = now - self.last_time
        self.last_time = now
        
        if dt <= 0: return
        
        error = v_ref - self.v_actual
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        self.prev_error = error
        
        correction = self.Kp*error + self.Ki*self.integral + self.Kd*derivative
        self.v_cmd = v_ref + correction
        
        # Strict speed limit clamp
        self.v_cmd = max(-self.v_max, min(self.v_max, self.v_cmd)) 
        
        msg = Float64()
        msg.data = float(self.v_cmd)
        self.pub.publish(msg)

    def print_status(self):
        v_ref = self.target_speed  # Fixed typo here
        self.get_logger().info(f'Speed Target: {v_ref:.1f} m/s | Actual: {self.v_actual:.2f} m/s | Cmd: {self.v_cmd:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = SpeedControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
