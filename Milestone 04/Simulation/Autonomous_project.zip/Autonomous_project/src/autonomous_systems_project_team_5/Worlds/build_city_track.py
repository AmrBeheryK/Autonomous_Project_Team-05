import math

def make_box(name, x, y, z, yaw, l, w, h, color):
    return f'''
    <model name="city_{name}">
      <static>true</static>
      <pose>{x:.3f} {y:.3f} {z:.3f} 0 0 {yaw:.3f}</pose>
      <link name="link">
        <collision name="collision"><geometry><box><size>{l:.3f} {w:.3f} {h:.3f}</size></box></geometry></collision>
        <visual name="city_visual_{name}">
          <geometry><box><size>{l:.3f} {w:.3f} {h:.3f}</size></box></geometry>
          <material><ambient>{color}</ambient><diffuse>{color}</diffuse></material>
        </visual>
      </link>
    </model>'''

def generate_world():
    sdf = '''<?xml version="1.0" ?>
<sdf version="1.8">
  <world name="City_Track">
    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"></plugin>
    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"></plugin>
    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"></plugin>

    <scene><ambient>1.0 1.0 1.0 1.0</ambient><background>0.5 0.8 0.9 1.0</background><shadows>false</shadows></scene>
    <light type="directional" name="city_sun_unique"><cast_shadows>false</cast_shadows><pose>0 0 10 0 0 0</pose><diffuse>0.8 0.8 0.8 1</diffuse><specular>0.2 0.2 0.2 1</specular><direction>-0.5 0.1 -0.9</direction></light>

    <model name="city_ground_plane">
      <static>true</static>
      <link name="link">
        <collision name="collision"><geometry><plane><normal>0 0 1</normal><size>20 20</size></plane></geometry></collision>
        <visual name="visual"><geometry><plane><normal>0 0 1</normal><size>20 20</size></plane></geometry><material><ambient>0.2 0.2 0.2 1</ambient><diffuse>0.2 0.2 0.2 1</diffuse></material></visual>
      </link>
    </model>
'''
    color, h, w, z = "0.8 0.4 0.0 1", 0.5, 0.05, 0.25
    
    # SHIFTED STRAIGHT WALLS (+1.75 to Y)
    sdf += make_box("out_top", 0, 3.75, z, 0, 3.0, w, h, color)
    sdf += make_box("out_bot", 0, -0.25, z, 0, 3.0, w, h, color)
    sdf += make_box("out_left", -2.5, 1.75, z, 1.571, 2.0, w, h, color)
    sdf += make_box("out_right", 2.5, 1.75, z, 1.571, 2.0, w, h, color)
    sdf += make_box("in_top", 0, 3.25, z, 0, 3.0, w, h, color)
    sdf += make_box("in_bot", 0, 0.25, z, 0, 3.0, w, h, color)
    sdf += make_box("in_left", -2.0, 1.75, z, 1.571, 2.0, w, h, color)
    sdf += make_box("in_right", 2.0, 1.75, z, 1.571, 2.0, w, h, color)

    # SHIFTED HIGH-POLY CURVES (+1.75 to Y centers, 15 segments)
    segments, corners = 25, [("TR", 1.5, 2.75, 0), ("TL", -1.5, 2.75, 1.571), ("BL", -1.5, 0.75, 3.142), ("BR", 1.5, 0.75, 4.712)]
    for c_name, cx, cy, start_angle in corners:
        for i in range(segments):
            theta = start_angle + (i + 0.5) * (math.pi/2/segments)
            sdf += make_box(f"oc_{c_name}_{i}", cx+1.0*math.cos(theta), cy+1.0*math.sin(theta), z, theta+1.571, 0.11, w, h, color)
            sdf += make_box(f"ic_{c_name}_{i}", cx+0.5*math.cos(theta), cy+0.5*math.sin(theta), z, theta+1.571, 0.06, w, h, color)

    # SHIFTED WAYPOINT MARKERS (Matched to the Outer-Hugging Racing Line)
    sdf += '''
    <model name="waypoint_markers">
      <static>true</static>
      <link name="link">
    '''
    path = []
    for i in range(0, 9): path.append([2.35, 0.75 + (i * 0.25)])
    for a in range(15, 91, 15): path.append([1.5 + 0.85*math.cos(math.radians(a)), 2.75 + 0.85*math.sin(math.radians(a))])
    for i in range(1, 13): path.append([1.5 - (i * 0.25), 3.60])
    for a in range(105, 181, 15): path.append([-1.5 + 0.85*math.cos(math.radians(a)), 2.75 + 0.85*math.sin(math.radians(a))])
    for i in range(1, 9): path.append([-2.35, 2.75 - (i * 0.25)])
    for a in range(195, 271, 15): path.append([-1.5 + 0.85*math.cos(math.radians(a)), 0.75 + 0.85*math.sin(math.radians(a))])
    for i in range(1, 13): path.append([-1.5 + (i * 0.25), -0.10])
    for a in range(285, 360, 15): path.append([1.5 + 0.85*math.cos(math.radians(a)), 0.75 + 0.85*math.sin(math.radians(a))])

    for idx, (wx, wy) in enumerate(path):
        sdf += f'''
        <visual name="wp_{idx}">
          <pose>{wx:.3f} {wy:.3f} 0.02 0 0 0</pose>
          <geometry><sphere><radius>0.03</radius></sphere></geometry>
          <material><ambient>0 1 0 1</ambient><diffuse>0 1 0 1</diffuse></material>
        </visual>
        '''
    sdf += '''
      </link>
    </model>
    </world>\n</sdf>'''
    with open("City_Track.world", "w") as f: f.write(sdf)

if __name__ == "__main__": generate_world()
