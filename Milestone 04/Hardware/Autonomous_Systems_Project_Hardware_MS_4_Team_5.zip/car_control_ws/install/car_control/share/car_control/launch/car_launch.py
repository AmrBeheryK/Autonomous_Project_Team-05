from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='car_control', executable='reference_node'),
        Node(package='car_control', executable='localization_node_aut'),
        Node(package='car_control', executable='velocity_node'),
        Node(package='car_control', executable='stanley_node_aut'),
       # Node(package='car_control', executable='esp_interface_node'),
    ])
