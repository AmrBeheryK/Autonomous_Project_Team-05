from setuptools import setup
import os
from glob import glob

package_name = 'car_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@email.com',
    description='Car control system',
    license='TODO',
    entry_points={
        'console_scripts': [
            'reference_node = car_control.reference_node:main',
            'localization_node_aut = car_control.localization_node_aut:main',
            'velocity_node = car_control.velocity_node:main',
            'stanley_node_aut = car_control.stanley_node_aut:main',
            'esp_interface_node = car_control.esp_interface_node:main',
        ],
    },
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/car_launch.py']),
        (os.path.join('share', package_name, 'data'),glob('data/*.csv')),
    ],
)
