# esp_interface_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32MultiArray
import serial
import time



class ESPInterfaceNode(Node):
    def __init__(self):
        super().__init__('esp_interface_node')

        # Publish RAW Arduino data
        self.raw_pub = self.create_publisher(String, '/arduino_data', 10)

        # Receive motor commands
        self.cmd_sub = self.create_subscription(
            Float32MultiArray,
            '/steering_cmd',
            self.cmd_callback,
            10
        )

        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

        # Power cycle the microcontroller at startup
        self._power_cycle()

        self.timer = self.create_timer(0.02, self.read_serial)

        self.get_logger().info("ESP Interface Node (RAW MODE) Started")

    def _power_cycle(self):
        """Send a soft reset command to the ESP32 and wait for it to reboot."""
        self.get_logger().info("Sending soft reset to ESP32...")

        self.ser.reset_input_buffer()
        self.ser.write(b"RESET\n")  # your firmware must handle this command
        self.get_logger().info("Reset command sent, waiting for ESP32 to reboot...")

        time.sleep(2.0)  # wait for reboot + boot messages to pass
        self.ser.reset_input_buffer()
        self.get_logger().info("ESP32 should be ready")

    def read_serial(self):
        try:
            line = self.ser.readline().decode('utf-8', errors='ignore').strip()
        except:
            return

        if not line:
            return

        msg = String()
        msg.data = line
        self.raw_pub.publish(msg)

    def cmd_callback(self, msg):
        servo_angle = float(msg.data[0])
        pwm = int(msg.data[1])

        cmd = f"{servo_angle},{pwm}\n"
        self.ser.write(cmd.encode())

    def destroy_node(self):
        try:
            self.ser.write(b"90,0\n")  # safety stop
            self.ser.close()
        except:
            pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = ESPInterfaceNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
