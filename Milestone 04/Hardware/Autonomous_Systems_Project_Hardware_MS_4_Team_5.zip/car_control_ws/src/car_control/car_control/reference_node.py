# reference_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import math
import csv
from ament_index_python.packages import get_package_share_directory
import os

pkg_path = get_package_share_directory('car_control')
csv_path = os.path.join(pkg_path, 'data', 'waypoints.csv')

class ReferenceNode(Node):
    def __init__(self):
        super().__init__('reference_node')

        self.pub = self.create_publisher(Float32MultiArray, '/reference', 10)

        self.sub_state = self.create_subscription(
            Float32MultiArray, '/state', self.state_callback, 10)

        # Load waypoints
        self.waypoints = self.load_waypoints(csv_path)
        #self.waypoints=[[0,0],[0,0.25],[0,0.5],[0,0.75],[0,1],[0,1.25],[0,1.5],[0,1.75],[0,2],[0.25,2],[0.5,2],[0.75,2],
        #                [1,2],[1.25,2],[1.5,2],[1.75,2],[2,2],[2,1.75],[2,1.5],[2,1.25],[2,1],[2,0.75],[2,0.5],
        #               [2,0.25],[2,0],[1.75,0],[1.5,0],[1.25,0],[1,0],[0.75,0],[0.5,0],[0.25,0],[0,0],[-1,-1]]

        self.index = 1

        # Parameters
        self.v_max = 0.19
        self.k_curvature = 2
        self.threshold = 0.4

        self.x = 0.0
        self.y = 0.0

        self.timer = self.create_timer(0.05, self.timer_callback)

    def load_waypoints(self, filename):
        waypoints = []
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            next(reader)  # skip header
            for row in reader:
                waypoints.append([float(row[0]), float(row[1])])
        return waypoints

    def state_callback(self, msg):
        self.x = msg.data[0]
        self.y = msg.data[1]

    def compute_curvature(self, p_prev, p_curr, p_next):
        dx1 = p_curr[0] - p_prev[0]
        dy1 = p_curr[1] - p_prev[1]

        dx2 = p_next[0] - p_curr[0]
        dy2 = p_next[1] - p_curr[1]

        angle1 = math.atan2(dy1, dx1)
        angle2 = math.atan2(dy2, dx2)

        return abs(angle2 - angle1)

    def timer_callback(self):
        if self.index >= len(self.waypoints) - 1:
            x_ref, y_ref = self.waypoints[-1]
            yaw_ref = 0.0
            v_ref = 0.0
        else:
            p_prev = self.waypoints[self.index - 1]
            p_curr = self.waypoints[self.index]
            p_next = self.waypoints[self.index + 1]

            x_ref, y_ref = p_curr

            dx = p_next[0] - p_curr[0]
            dy = p_next[1] - p_curr[1]
            yaw_ref = math.atan2(dy, dx)

            curvature = self.compute_curvature(p_prev, p_curr, p_next)
            v_ref = self.v_max / (1 + self.k_curvature * curvature)

            # ✅ waypoint switching
            dist = math.sqrt((x_ref - self.x)**2 + (y_ref - self.y)**2)
            if dist < self.threshold:
                self.index += 1

        msg = Float32MultiArray()
        msg.data = [float(x_ref), float(y_ref), float(yaw_ref), float(v_ref)]
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ReferenceNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()