# velocity_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import time

class VelocityNode(Node):
    def __init__(self):
        super().__init__('velocity_node')

        self.sub_state = self.create_subscription(
            Float32MultiArray, '/state', self.state_callback, 10)

        self.sub_ref = self.create_subscription(
            Float32MultiArray, '/reference', self.ref_callback, 10)

        self.pub = self.create_publisher(Float32MultiArray, '/pwm_cmd', 10)

        # PID
        self.Kp = 2.0
        self.Ki = 0
        self.Kd = 0
        #self.Ki = 0.5
        #self.Kd = 0.1

        self.integral = 0.0
        self.prev_error = 0.0
        self.last_time = time.time()

        # Vehicle params
        self.v_max = 0.19
        self.pwm_min = 150
        self.pwm_max = 255

        self.v = 0.0
        self.v_ref = 0.0

    def state_callback(self, msg):
        self.v = msg.data[3]
        self.compute_pwm()

    def ref_callback(self, msg):
        self.v_ref = msg.data[3]

    def compute_pwm(self):
        now = time.time()
        dt = now - self.last_time
        self.last_time = now

        if dt <= 0:
            return

        # ✅ STOP CONDITION
        if self.v_ref < 0.01:
            self.integral = 0.0
            pwm = 0
        else:
            error = self.v_ref - self.v
            self.integral += error * dt
            derivative = (error - self.prev_error) / dt

            correction = self.Kp*error + self.Ki*self.integral + self.Kd*derivative
            self.prev_error = error

            v_cmd = self.v_ref + correction
            v_cmd = max(0.0, min(self.v_max, v_cmd))

            v_ratio = v_cmd / self.v_max
            pwm = self.pwm_min + v_ratio * (self.pwm_max - self.pwm_min)

            pwm = int(max(0, min(255, pwm)))

            # anti-windup
            if pwm == 0 or pwm == 255:
                self.integral *= 0.9

        msg = Float32MultiArray()
        msg.data = [float(pwm)]
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = VelocityNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()