import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Float32MultiArray
import time
import numpy as np

def normalize_angle(angle):
    return (angle + np.pi) % (2*np.pi) - np.pi

class LocalizationNode(Node):

    def __init__(self):
        super().__init__('localization_node_aut')

        # Publisher
        self.pub = self.create_publisher(Float32MultiArray, '/state', 10)

        # Subscriber (Fake Arduino)
        self.sub = self.create_subscription(
            String,
            '/arduino_data',
            self.callback,
            10
        )

        self.last_time = None
        # EKF state: [x, y, theta]
        self.x = np.array([[0.0], [0.0], [0.0]])

        # Covariance matrix
        self.P = np.eye(3) * 0.1

        self.get_logger().info("Localization node started (Fake Arduino mode)")

    # ✅ CORRECT CALLBACK
    def callback(self, msg):

        line = msg.data
        self.get_logger().info(line)

        # Ignore invalid data
        if not line.startswith("DATA:"):
            return

        try:
            data = line.replace("DATA:", "")
            parts = data.split(',')
            # ✅ Expect: yaw_measure, v (and optionally yaw_rate)
            yaw_measure = np.deg2rad(float(parts[0]))  # ✅ convert to radians
            v = float(parts[1])
            omega=np.deg2rad(float(parts[2]))  # ✅ convert to radians
        except:
            return

        now = time.time()
        if self.last_time is None:
            self.last_time = now
            return
        dt = now - self.last_time
        dt = max(0.02, min(0.1, dt))  # clamp to sane range
        self.last_time = now
        theta = self.x[2, 0]

        # ---------------------------
        # EKF PREDICTION
        # ---------------------------
        F = np.array([
            [1, 0, -v * dt * np.sin(theta)],
            [0, 1,  v * dt * np.cos(theta)],
            [0, 0, 1]
        ])

        B = np.array([
            [dt * np.cos(theta)],
            [dt * np.sin(theta)],
            [0]
        ])
        C = np.array([
            [0],
            [0],
            [dt]
        ])


        self.x = self.x + B * v+ C * omega

        Q = np.eye(3) * 0.01
        self.P = F @ self.P @ F.T + Q

        # ---------------------------
        # EKF UPDATE (Yaw only)
        # ---------------------------
        H = np.array([[0, 0, 1]])
        R = np.array([[0.01]])

        z = np.array([[yaw_measure]])

        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)

        self.x = self.x + K @ y
        self.P = (np.eye(3) - K @ H) @ self.P

        # ---------------------------
        # Publish msg state
        # ---------------------------
        self.x[2,0] = normalize_angle(self.x[2,0])
        msg = Float32MultiArray()
        msg.data = [
        float(self.x[0, 0]),  # x
        float(self.x[1, 0]),  # y
        float(self.x[2, 0]),  # yaw
        float(v)              # velocitys
        ]
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()