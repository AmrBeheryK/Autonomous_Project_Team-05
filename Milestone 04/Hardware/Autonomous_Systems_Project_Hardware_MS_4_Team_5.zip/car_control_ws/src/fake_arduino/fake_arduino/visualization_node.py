# visualization_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import matplotlib.pyplot as plt
import math

class VisualizationNode(Node):
    def __init__(self):
        super().__init__('visualization_node')

        self.sub = self.create_subscription(
            Float32MultiArray, '/state', self.state_callback, 10)

        self.x = []
        self.y = []
        self.yaw = 0.0

        plt.ion()
        self.fig, self.ax = plt.subplots()

        self.timer = self.create_timer(0.1, self.update_plot)

    def state_callback(self, msg):
        self.x.append(msg.data[0])
        self.y.append(msg.data[1])
        self.yaw = msg.data[2]

        # limit memory
        if len(self.x) > 500:
            self.x.pop(0)
            self.y.pop(0)

    def update_plot(self):
        if len(self.x) == 0:
            return

        self.ax.clear()

        self.ax.plot(self.x, self.y, 'b-', label='Trajectory')

        x = self.x[-1]
        y = self.y[-1]

        dx = 0.3 * math.cos(self.yaw)
        dy = 0.3 * math.sin(self.yaw)

        self.ax.arrow(x, y, dx, dy,
                      head_width=0.1, head_length=0.1,
                      fc='r', ec='r')

        self.ax.set_title("Vehicle State")
        self.ax.set_xlabel("X")
        self.ax.set_ylabel("Y")
        self.ax.axis('equal')
        self.ax.grid()
        self.ax.legend()

        plt.draw()
        plt.pause(0.001)


def main(args=None):
    rclpy.init(args=args)
    node = VisualizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    plt.close()