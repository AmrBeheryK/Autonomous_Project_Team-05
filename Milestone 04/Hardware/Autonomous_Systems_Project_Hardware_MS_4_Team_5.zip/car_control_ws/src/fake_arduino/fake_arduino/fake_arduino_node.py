import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32MultiArray
import math
import random

class FakeArduino(Node):
    def __init__(self):
        super().__init__('fake_arduino')

        # Publisher (same as before)
        self.pub = self.create_publisher(String, '/arduino_data', 10)

        # NEW: subscribe to controller output
        self.sub = self.create_subscription(
            Float32MultiArray,
            '/steering_cmd',
            self.cmd_callback,
            10
        )

        # Vehicle state
        self.yaw = 0.0
        self.v = 0.0

        # Inputs from controller
        self.servo_angle = 90.0
        self.pwm = 0.0

        # Parameters
        self.L = 0.25       # wheelbase
        self.dt = 0.05      # 20 Hz
        self.max_speed = 0.19

        self.timer = self.create_timer(self.dt, self.update)

    def cmd_callback(self, msg):
        self.servo_angle = msg.data[0]
        self.pwm = msg.data[1]

    def update(self):
        # --- Convert PWM → velocity ---
        target_v = (self.pwm / 255.0) * self.max_speed
        self.v += 0.4 * (target_v-self.v)

        # --- Convert servo → steering angle ---
        delta_deg = self.servo_angle - 90.0
        delta = math.radians(delta_deg)

        # --- Compute yaw rate (gyro Z) ---
        gyro_z_true = (self.v / self.L) * math.tan(delta)

        # Add gyro noise + bias (realistic IMU simulation)
        gyro_bias = 0.005          # rad/s constant drift
        gyro_noise_std = 0.008     # rad/s white noise
        gyro_z_measured = gyro_z_true + gyro_bias + random.gauss(0, gyro_noise_std)

        # --- Update yaw (simple bicycle model) ---
        self.yaw += (self.v / self.L) * math.tan(delta) * self.dt + random.gauss(0, 0.01)

        # Normalize yaw
        self.yaw = math.atan2(math.sin(self.yaw), math.cos(self.yaw))

        # Publish SAME FORMAT as before
        msg = String()
        msg.data = f"DATA:{math.degrees(self.yaw)},{self.v},{math.degrees(gyro_z_measured)}"
        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = FakeArduino()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
