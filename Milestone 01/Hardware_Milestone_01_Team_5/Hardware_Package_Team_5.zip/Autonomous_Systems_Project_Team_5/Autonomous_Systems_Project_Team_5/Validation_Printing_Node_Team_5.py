import rclpy
from rclpy.node import Node

def main(args=None):
    rclpy.init(args=args)
    node = Node('validation_printing_node')
    node.get_logger().info('Hello world')
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
