#include <Arduino.h>


#define ENCODER_PIN 27
#define MOTOR_PWM_PIN 17
#define DIR1_PIN 12
#define DIR2_PIN 14

#define PWM_FREQ 20000
#define PWM_RES 8
const int pwmChannel = 5;

volatile long encoder_ticks = 0;
const float TICKS_PER_METER = 6998;
const float vref=0.09;
const float vmax=0.11;
const int pwmmin=150;
const float kp=2.0;
float alpha = 0.15f; // filter strength for the encoder calculations
float v = 0.0;    // speed


void setup() {
  Serial.begin(115200);
  pinMode(DIR1_PIN, OUTPUT);
  pinMode(DIR2_PIN, OUTPUT);

  pinMode(ENCODER_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN), countEncoder, RISING);

  ledcSetup(pwmChannel, PWM_FREQ, PWM_RES);
  ledcAttachPin(MOTOR_PWM_PIN, pwmChannel);
  delay(3000);
}

void loop() {
  digitalWrite(DIR1_PIN, HIGH);
  digitalWrite(DIR2_PIN, LOW);
  computeSpeed();
  float difference= vref-v;
  float correction= kp*difference;
  float vcmd=vref+correction;
  float vratio=constrain(vcmd,0,vmax)/vmax;
  Serial.print("Velocity: ");
  Serial.println(v);
  int pwm=(int)(pwmmin+vratio*(255-pwmmin));
  ledcWrite(pwmChannel, constrain(pwm, 0, 255));
  delay(20);
}

void countEncoder() { encoder_ticks++; }


void computeSpeed() {
  static long last_ticks = 0;
  static unsigned long last_time = 0;
  noInterrupts();
  long ticks = encoder_ticks;
  interrupts();
  unsigned long t = millis();
  long dticks = ticks - last_ticks;
  float distance = (float)dticks / TICKS_PER_METER;
  float dt = (t - last_time) / 1000.0;
  v = alpha * (distance / dt) + (1 - alpha) * v;   
  last_ticks = ticks;
  last_time = t;
}